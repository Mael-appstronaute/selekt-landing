import { NotFoundView } from "@/components/pages/NotFoundView";

export default function NotFound() {
  return <NotFoundView locale="en" />;
}
